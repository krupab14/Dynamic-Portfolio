<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .login-form {
            max-width: 500px;
            margin: auto;
        }
        .form-label,
        .btn,
        h3 {
            color: #000000;
        }
        h3 {
            font-size: 1.5rem;
        }
        label {
            font-weight: bold;
        }
        .error-message {
            color: red;
            font-size: 0.875rem;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="d-flex justify-content-center align-items-center vh-100">
    <div class="col-md-4 login-form">
        <div class="card p-4">
            <h3 class="text-center mb-4">Login</h3>
            <form id="loginForm" method="POST" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="username" class="form-label">Enter Username:</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" autocomplete="off" required>
                    <div class="invalid-feedback">
                        Please enter your username.
                    </div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Enter Password:</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" autocomplete="off" required>
                    <div class="invalid-feedback">
                        Please enter your password.
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Submit</button>
                <!-- Error message will be displayed here -->
                <div id="error-message" class="error-message">
                    <?php if (isset($error_message)) { echo $error_message; } ?>
                </div>
            </form>
        </div>
    </div>
</div>

<?php

    // PHP backend part to check credentials in the database
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $servername = "localhost";
        $db_username = "root";
        $db_password = "";
        $dbname = "cv_db";

        // Create connection
        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Get username and password from the form
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Prepare a SQL statement to prevent SQL injection
        $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $password); // Bind username and password as strings
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if any user found with the provided credentials
        if ($result->num_rows > 0) {
            // User found, set session variables

            // Redirect to the admin dashboard (index.php)
            header("Location: index.php");
            exit();
        } else {
            // User not found, set the error message
            $error_message = 'Incorrect username or password.';
        }

        $stmt->close();
        $conn->close();
    }
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function () {
        'use strict'

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
    })()

    // Client-side validation for incorrect username/password
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent form submission

        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;

        // Clear any existing error message
        document.getElementById('error-message').textContent = '';

        // Basic check for username and password fields
        if (username.trim() === '' || password.trim() === '') {
            document.getElementById('error-message').textContent = 'Both fields are required.';
            return;
        }

        // If fields are valid, submit the form and wait for the PHP backend response
        this.submit();
    });
</script>
