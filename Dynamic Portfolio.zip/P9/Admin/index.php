
<?php
// Include database connection
include 'header.php'; 
include 'db-connect.php';

// Fetch data from the homepage table
$query = "SELECT * FROM homepage LIMIT 1"; // Assuming there is only one record
$result = $conn->query($query);

// Check if any data is returned
$homepageData = null;
if ($result->num_rows > 0) {
    $homepageData = $result->fetch_assoc();
}

// Handle form submission
$successMessage = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $home_title = $_POST['titleUpload'];
    $home_description = $_POST['introText'];

    // Handle file upload if a new image is provided
    $home_image = null;
    if (isset($_FILES['imageUpload']) && $_FILES['imageUpload']['error'] == 0) {
        $image_name = $_FILES['imageUpload']['name'];
        $image_tmp_name = $_FILES['imageUpload']['tmp_name'];
        
        // Destination path in the same directory as this PHP script
        $image_destination = __DIR__ . '/' . $image_name; // Same directory as the script

        // Move the uploaded image to the current directory
        if (move_uploaded_file($image_tmp_name, $image_destination)) {
            $home_image = $image_name;
        } else {
            echo "Failed to upload the image.";
        }
    }

    // If no image is uploaded, use default image
    if (!$home_image) {
        $home_image = 'me.jpeg';  // Default image
    }

    // Update or insert data in the database
    if ($homepageData) {
        // Update existing record
        $sql = "UPDATE homepage SET home_title = ?, home_description = ?, home_image = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $home_title, $home_description, $home_image, $homepageData['id']);
    } else {
        // Insert new record
        $sql = "INSERT INTO homepage (home_title, home_description, home_image) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $home_title, $home_description, $home_image);
    }

    // Execute query
    if ($stmt->execute()) {
        // Set success message
        $successMessage = true;
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<div class="container mt-5">
    <!-- Form Container -->
    <form action="#" method="POST" enctype="multipart/form-data" id="homepageForm" onsubmit="return validateForm()">
        <!-- Profile Image Input -->
        <div class="mb-3">
            <label for="imageUpload" class="form-label">Profile Image</label>
            <input type="file" class="form-control" id="imageUpload" name="imageUpload" accept="image/*" onchange="previewImage(event)">
            <!-- Preview Image Box -->
            <div id="imagePreview" class="mt-3" style="display: <?php echo $homepageData && $homepageData['home_image'] ? 'block' : 'none'; ?>;">
                <!-- If an image exists, show it as a preview -->
                <?php if ($homepageData && $homepageData['home_image']): ?>
                    <div class="border p-2">
                        <img src="<?php echo $homepageData['home_image']; ?>" alt="Profile Image" class="img-fluid" width="200">
                    </div>
                <?php endif; ?>
            </div>
            <!-- Error message for image -->
            <div id="imageError" class="text-danger" style="display: none;">Please select a profile image.</div>
        </div>

        <!-- Profile Title Input -->
        <div class="mb-3">
            <label for="titleUpload" class="form-label">Profile Title</label>
            <input type="text" class="form-control" placeholder="Enter your profile title" id="titleUpload" name="titleUpload" value="<?php echo $homepageData ? htmlspecialchars($homepageData['home_title']) : ''; ?>">
            <!-- Error message for title -->
            <div id="titleError" class="text-danger" style="display: none;">Please fill this field.</div>
        </div>

        <!-- Intro Paragraph Input -->
        <div class="mb-3">
            <label for="introText" class="form-label">Introduction Text</label>
            <textarea class="form-control" id="introText" name="introText" rows="5" placeholder="Write your intro paragraph here..."><?php echo $homepageData ? htmlspecialchars($homepageData['home_description']) : ''; ?></textarea>
            <!-- Error message for intro -->
            <div id="introError" class="text-danger" style="display: none;">Please fill this field.</div>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="mb-3 btn btn-primary">Submit</button>

        <!-- Success Message -->
        <div id="successMessage" class="alert alert-success mt-3" style="display: <?php echo $successMessage ? 'block' : 'none'; ?>">Data inserted successfully.</div>
    </form>
</div>
<script>
// JavaScript function to preview the image
function previewImage(event) {
    var reader = new FileReader();
    var output = document.getElementById('imagePreview');
    output.style.display = 'block'; // Show the preview box

    reader.onload = function () {
        var imgElement = document.createElement('img');
        imgElement.src = reader.result;
        imgElement.classList.add('img-fluid');
        imgElement.width = 200; // Set a fixed width for the preview image

        // Clear previous image and add the new preview image
        output.innerHTML = ''; // Clear the container
        output.appendChild(imgElement); // Append the new image
    };

    reader.readAsDataURL(event.target.files[0]);
}

// JavaScript validation for the form
function validateForm() {
    let isValid = true;

    // Reset error messages
    document.getElementById('titleError').style.display = 'none';
    document.getElementById('introError').style.display = 'none';
    document.getElementById('imageError').style.display = 'none';

    // Validate Profile Title
    let title = document.getElementById('titleUpload').value.trim();
    if (title === '') {
        document.getElementById('titleError').style.display = 'block';
        isValid = false;
    }

    // Validate Introduction Text
    let introText = document.getElementById('introText').value.trim();
    if (introText === '') {
        document.getElementById('introError').style.display = 'block';
        isValid = false;
    }

    // Validate Image (if no image is selected, use default)
    let image = document.getElementById('imageUpload').files[0];
    if (!image && document.getElementById('imagePreview').style.display === 'none') {
        document.getElementById('imageError').style.display = 'block';
        isValid = false;
    }

    // Return the validation result
    return isValid;
}

// Hide success message on page load
window.onload = function() {
    // Hide success message after 5 seconds (optional)
    setTimeout(function() {
        document.getElementById('successMessage').style.display = 'none';
    }, 5000);

    // Show validation error messages if they were set in the previous form submission
    let hasError = <?php echo $successMessage ? 'false' : 'true'; ?>; // Check if there was an error during the last form submission
    if (hasError) {
        // Show validation messages (only if there's an error and the page was not refreshed)
        document.getElementById('titleError').style.display = document.getElementById('titleUpload').value.trim() === '' ? 'block' : 'none';
        document.getElementById('introError').style.display = document.getElementById('introText').value.trim() === '' ? 'block' : 'none';
        document.getElementById('imageError').style.display = document.getElementById('imageUpload').files.length === 0 && document.getElementById('imagePreview').style.display === 'none' ? 'block' : 'none';
    }
};

</script>
<?php include "footer.php" ?>