function createCircle(percentage) {
    const radius = 75
    const circumference = 2 * Math.PI * radius
    const offset = circumference - (percentage / 100) * circumference

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    svg.setAttribute('width', '150')
    svg.setAttribute('height', '150')
    svg.classList.add('progress-ring-svg')

    // Background circle
    const circleBackground = document.createElementNS('http://www.w3.org/2000/svg', 'circle')
    circleBackground.setAttribute('cx', '75')
    circleBackground.setAttribute('cy', '75')
    circleBackground.setAttribute('r', '75')
    circleBackground.classList.add('progress-ring__circle-background')
    svg.appendChild(circleBackground)

    // Progress circle
    const circleProgress = document.createElementNS('http://www.w3.org/2000/svg', 'circle')
    circleProgress.setAttribute('cx', '75')
    circleProgress.setAttribute('cy', '75')
    circleProgress.setAttribute('r', '75')
    circleProgress.classList.add('progress-ring__circle-progress')
    circleProgress.style.strokeDashoffset = offset
    svg.appendChild(circleProgress)

    const text = document.createElement('div')
    text.classList.add('percentage-text')
    text.textContent = `${percentage}%`

    const container = document.createElement('div')
    container.classList.add('progress-ring')
    container.appendChild(svg)
    container.appendChild(text)

    return container
}

document.addEventListener('DOMContentLoaded', function () {
    const progressContainer = document.querySelectorAll('.progress-ring')

    progressContainer.forEach(function (progressRing) {
        const percentage = progressRing.getAttribute('data-percentage')
        const circle = createCircle(percentage)
        progressRing.innerHTML = ''
        progressRing.appendChild(circle)
    })
})

const menuBtn = document.querySelector('.menu-btn')
const sidebarContent = document.querySelector('.sidebar-content')

menuBtn.addEventListener('click', (event) => {
    sidebarContent.classList.toggle('active')
    event.stopPropagation()
})

document.addEventListener('click', (event) => {
    if (
        sidebarContent.classList.contains('active') &&
        !sidebarContent.contains(event.target) &&
        !menuBtn.contains(event.target)
    ) {
        sidebarContent.classList.remove('active')
    }
})
