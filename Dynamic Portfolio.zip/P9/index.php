
<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Metadata and Fonts -->
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" />
        <link rel="stylesheet" href="./style.css" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link
            href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800&display=swap"
            rel="stylesheet"
        />
        <title>Krupa Bhalsod</title>
    </head>
    <body>
        <!-- Container for Sidebar and Main Content -->
        <div class="cv-page">
            <!-- =====================SIDEBAR===================== -->
            <div class="sidebar-container">
                <div class="sidebar">
                    <!-- Logo Section -->
                    <div class="logo">
                        <a href="#main-page">Krupa Bhalsod</a>
                    </div>

                    <!-- Navigation Section -->
                    <div class="navigation">
                        <ul>
                            <li><a href="#about">About</a></li>
                            <li><a href="#Qualifications">Qualifications</a></li>
                            <li><a href="#skills">Skills</a></li>
                            <li><a href="#internships">Internships</a></li>
                            <li><a href="#projects">Projects</a></li>
                            <li><a href="#contact">Contact</a></li>
                            <li><a href='Admin/login.php'>Login</a></li>
                        </ul>
                    </div>

                    <!-- Footer Section -->
                    <div class="footer">
                        <h6>&copy; All rights reserved | Krupa Bhalsod</h6>
                        <div class="social-links">
                            <a href=""><i class="bx bxl-instagram-alt"></i></a>
                            <a href="#"><i class="bx bxl-gmail"></i></a>
                            <a href=""><i class="bx bxl-github"></i></a>
                            <a href=""><i class="bx bxl-linkedin-square"></i></a>
                        </div>
                    </div>
                </div>

                <div class="navbar">
                    <!-- Logo Section -->
                    <div class="logo">
                        <a href="#main-page">Krupa Bhalsod</a>
                    </div>

                    <!-- Menu Button -->
                    <div class="menu-btn">
                        <svg viewBox="0 0 24 24" fill="white">
                            <path d="M3 4H21V6H3V4ZM3 11H21V13H3V11ZM3 18H21V20H3V18Z"></path>
                        </svg>
                    </div>
                </div>

                <!-- Sidebar Content (will be hidden on mobile) -->
                <div class="sidebar-content">
                    <!-- Navigation Section -->
                    <div class="navigation">
                        <ul>
                            <li><a href="#about">About</a></li>
                            <li><a href="#Qualifications">Qualifications</a></li>
                            <li><a href="#skills">Skills</a></li>
                            <li><a href="#internships">Internships</a></li>
                            <li><a href="#projects">Projects</a></li>
                            <li><a href="#contact">Contact</a></li>
                            <li><a href="Admin/login.php">Login</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- =====================MAIN WEBSITE===================== -->
            <?php
            // Database connection details (replace with your actual credentials)
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "cv_db";

            // Create a connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);

            }

            // SQL query to fetch data from the homepage table
            $sql = "SELECT home_title, home_description, home_image FROM homepage";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $home_title = $row["home_title"];
                $home_description = $row["home_description"];
                $home_image = $row["home_image"];
            } else {
                echo "0 results";
            }
            ?>
            <div class="web-content">
                <div class="main-page" id="main-page">
                    <div class="main-img">
                        <img src="<?php echo $home_image; ?>" alt="MY IMAGE" class="profile-image" />
                    </div>

                    <div class="main-content">
                        <h1 class="main-title"><?php echo $home_title; ?></h1>
                        <p class="main-description">
                            <?php echo $home_description; ?>
                        </p>
                        <div class="main-btn">
                            <a href="" class="btn">Download Resume</a>
                            <a href="" class="btn">Let's Connect</a>
                        </div>
                    </div>
                </div>

                <?php
                $sql = "SELECT about_image, about_text FROM about";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $about_image = $row["about_image"];
                    $about_text = $row["about_text"];
                } else {
                    echo "0 results";
                }
                ?>
                <!-- About Section -->
                <?php
                    $sql = "SELECT about_image, about_text FROM about";

                    if ($result = $conn->query($sql)) {
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $about_image = $row["about_image"];
                            $about_text = $row["about_text"];
                        } else {
                            echo "0 results";
                        }
                    } else {
                        echo "Error: " . $conn->error;
                    }
                ?>
                <div class="about-section">
                    <div class="heading" id="about">About me</div>
                    <div class="about-img">
                        <img src="<?php echo $about_image; ?>" alt="about-img" />
                    </div>
                    <div class="about-content">
                        <p>
                            <?php echo $about_text; ?>
                        </p>
                        <a href="" class="btn" id="about-btn">Let's Connect</a>
                    </div>
                </div>
                    <br><br>

                <div class="heading" id="Qualifications">Qualifications</div>   
                <?php
// Assume you have a database connection stored in $conn

                $query = "SELECT * FROM qualifications ORDER BY id"; // Fetch qualifications in order
                $result = mysqli_query($conn, $query);

                // Fetch total number of qualifications
                $totalRows = mysqli_num_rows($result);

                // Check if there are results
                if ($totalRows > 0) {
                    $qualifications = mysqli_fetch_all($result, MYSQLI_ASSOC); // Fetch all results at once
                    $count = count($qualifications);

                    for ($i = 0; $i < $count; $i++) {
                        $degree = $qualifications[$i]['degree'];
                        $college = $qualifications[$i]['college'];
                        $duration = $qualifications[$i]['duration'];
                        $cgpa = $qualifications[$i]['cgpa'];

                        $isFirst = ($i == 0); // Is this the first entry?
                        $isLast = ($i == $count - 1); // Is this the last entry?

                        if ($i % 2 == 0) {
                            // Even index: Right side of the timeline
                            echo '<div class="qualification">';
                            echo '<div class="qualification-details">';
                            echo '<p class="qualification_title">' . htmlspecialchars($degree) . '</p>';
                            echo '<p class="qualification_subtitle">' . htmlspecialchars($college) . '</p>';
                            echo '<p class="qualification_duration">' . htmlspecialchars($duration) . '</p>';
                            echo '<p class="qualification_score">CGPA - ' . htmlspecialchars($cgpa) . '</p>';
                            echo '</div>';
                            echo '<div>';
                            echo '<div class="timeline_circle"></div>';

                            // Only show the timeline line if this is NOT the first or last qualification
                            if (!$isLast) {
                                echo '<span class="timeline-line"></span>';
                            }

                            echo '</div>';
                            echo '<div></div>';
                            echo '</div>';
                        } else {
                            // Odd index: Left side of the timeline
                            echo '<div class="qualification">';
                            echo '<div></div>';
                            echo '<div>';
                            echo '<div class="timeline_circle"></div>';

                            // Only show the timeline line if this is NOT the first or last qualification
                            if (!$isFirst && !$isLast) {
                                echo '<span class="timeline-line"></span>';
                            }

                            echo '</div>';
                            echo '<div class="qualification-details">';
                            echo '<p class="qualification_title">' . htmlspecialchars($degree) . '</p>';
                            echo '<p class="qualification_subtitle">' . htmlspecialchars($college) . '</p>';
                            echo '<p class="qualification_duration">' . htmlspecialchars($duration) . '</p>';
                            echo '<p class="qualification_score">CGPA - ' . htmlspecialchars($cgpa) . '</p>';
                            echo '</div>';
                            echo '</div>';
                        }
                    }
                } else {
                    echo "No qualifications found.";
                }
                ?>


                                

                <?php
                // Fetch skills from the database
                $sql = "SELECT skill_name, skill_percentage FROM skills";
                $result = $conn->query($sql);

                // Initialize a counter to group skills in rows of 4
                $counter = 0;
                ?>

                <div class="skills">
                    <div class="heading" id="skills">Skills</div>
                    <?php
                    while($row = $result->fetch_assoc()) {
                        // Start a new container for every set of 4 skills
                        if ($counter % 4 == 0) {
                            if ($counter > 0) {
                                echo "</div>"; // Close previous container
                            }
                            echo "<div class='skills-container'>"; // Start new container
                        }

                        // Fetch skill details
                        $skill_name = $row['skill_name'];
                        $skill_percentage = $row['skill_percentage'];
                        ?>
                        
                        <!-- Skill HTML -->
                        <div class="skill">
                            <div class="skill-name"><?= $skill_name ?></div>
                            <div class="progress-ring" data-percentage="<?= $skill_percentage ?>">
                                <svg class="progress-ring__svg" width="150" height="150">
                                    <circle class="progress-ring__circle-background" cx="75" cy="75" r="70"></circle>
                                    <circle class="progress-ring__circle-progress" cx="75" cy="75" r="70" stroke-dasharray="471" stroke-dashoffset="<?= 471 - (471 * $skill_percentage / 100) ?>"></circle>
                                </svg>
                                <div class="percentage-text"><?= $skill_percentage ?>%</div>
                            </div>
                        </div>
                        
                        <?php
                        $counter++; // Increment counter
                    }

                    // Close the last skills container if necessary
                    if ($counter > 0) {
                        echo "</div>";
                    }
                    ?>
                </div>

                <?php
                $sql = "SELECT internship_role, internship_duration, internship_details FROM internships";
                $result = $conn->query($sql);
                ?>

                <!-- Internships Section -->
                <div class="internship-section">
                <div class="heading" id="internships">Internships</div>
                <div class="internship_container">
                    <?php
                    // Check if any internships are available
                    if ($result->num_rows > 0) {
                        // Loop through each row and display internship data
                        while ($row = $result->fetch_assoc()) {
                            $internship_role = $row['internship_role'];
                            $internship_duration = $row['internship_duration'];
                            $internship_details = $row['internship_details'];
                    ?>
                            <!-- Internship Entry -->
                            <div class="internship">
                                <div class="timeline_circle"></div>
                                <div class="timeline_line"></div>
                                <div class="internship-details">
                                    <h3><?= $internship_role ?></h3>
                                    <p class="internship-duration"><?= $internship_duration ?></p>
                                    <ul>
                                        <li><?= nl2br($internship_details) ?></li>
                                    </ul>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<p>No internships available.</p>";
                    }
                    ?>
                </div>
                </div>


                <?php
                $sql = "SELECT project_title, project_github_link, project_description FROM projects";
                $result = $conn->query($sql);
                ?>

                <!-- Projects Section -->
                <div class="heading" id="projects">Projects</div>
                <div class="projects-container">
                    <?php
                    // Check if any projects are available
                    if ($result->num_rows > 0) {
                        // Loop through each row and display project data
                        while ($row = $result->fetch_assoc()) {
                            $project_title = $row['project_title'];
                            $project_github_link = $row['project_github_link'];
                            $project_description = $row['project_description'];
                    ?>
                            <!-- Project Entry -->
                            <div class="projects">
                                <h3><?= $project_title ?></h3>
                                <a href="<?= $project_github_link ?>" target="_blank">View Project</a>
                                <p><?= nl2br($project_description) ?></p>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<p>No projects available.</p>";
                    }
                    ?>
                </div>
               <!-- Contact Section -->
                <div class="heading" id="contact">Contact Me</div>
                <div class="contact-form-container">
                <form class="contact-form" method="POST">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" name="name" required />
                        </div>

                        <div class="form-group">
                            <label for="contact">Contact Number</label>
                            <input type="tel" id="contact" name="contact" required />
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required />
                        </div>

                        <div class="form-group">
                            <label for="title">Message Title</label>
                            <input type="text" id="title" name="title" required />
                        </div>

                        <div class="form-group full-width">
                            <label for="message">Message</label>
                            <textarea id="message" name="message" rows="5" required></textarea>
                        </div>

                        <button type="submit" id="submit" class="btn">Submit</button>
                    </form>
                    <?php
                    if (isset($_POST['name']) && isset($_POST['contact']) && isset($_POST['email']) && isset($_POST['title']) && isset($_POST['message'])) {
                        $name = $_POST['name'];
                        $contact = $_POST['contact'];
                        $email = $_POST['email'];
                        $title = $_POST['title'];
                        $message = $_POST['message'];                       

                        $stmt = $conn->prepare("INSERT INTO contact (name, contact_number, email, message_title, message) VALUES (?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssss", $name, $contact, $email, $title, $message);

                        if ($stmt->execute()) {
                             
                        } else {    
                            echo "Error: " . $stmt->error;
                        }

                        $stmt->close(); 
                        $conn->close();
                    }
                    ?>

                </div>
                <div class="footer footer-mobile">
                    <h6>&copy; All rights reserved | Krupa Bhalsod</h6>
                    <div class="social-links">
                        <a href=""><i class="bx bxl-instagram-alt"></i></a>
                        <a href=""><i class="bx bxl-gmail"></i></a>
                        <a href=""><i class="bx bxl-github"></i></a>
                        <a href=""><i class="bx bxl-linkedin-square"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <script src="./script.js"></script>
    </body>
</html>
